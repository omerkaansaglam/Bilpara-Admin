export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: 'AIzaSyAbOKKRQ3nU3HuEAfkSJKfCkpQEjvVLVLY',
    authDomain: 'bilpara-d1d71.firebaseapp.com',
    databaseURL: 'https://bilpara-d1d71-default-rtdb.firebaseio.com',
    projectId: 'bilpara-d1d71',
    storageBucket: 'bilpara-d1d71.appspot.com',
    messagingSenderId: '844311997114',
    appId: '1:844311997114:web:a9364e2010fac1cf1ab083'
  }
};
