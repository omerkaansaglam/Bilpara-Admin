// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: 'AIzaSyAbOKKRQ3nU3HuEAfkSJKfCkpQEjvVLVLY',
    authDomain: 'bilpara-d1d71.firebaseapp.com',
    databaseURL: 'https://bilpara-d1d71-default-rtdb.firebaseio.com',
    projectId: 'bilpara-d1d71',
    storageBucket: 'bilpara-d1d71.appspot.com',
    messagingSenderId: '844311997114',
    appId: '1:844311997114:web:a9364e2010fac1cf1ab083'
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
