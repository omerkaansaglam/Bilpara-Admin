import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {AngularFireModule} from '@angular/fire';
import {AngularFireDatabaseModule} from '@angular/fire/database';
import {AppComponent} from './app.component';
import {environment} from '../environments/environment';
import {CreateUserComponent} from './Pages/uaerUpdate/user-update.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {UserListComponent} from './Pages/user-list/user-list.component';
import {NavComponent} from './Pages/nav/nav.component';


import {appRoutes, AppRoutingModule} from './app-routing.module';
import {HomepageComponent} from './Pages/homepage/homepage.component';
import {KullaniciIslemComponent} from './Pages/kullanici-islem/kullanici-islem.component';
import {UygulamaislemComponent} from './Pages/uygulamaislem/uygulamaislem.component';
import {RouterModule} from '@angular/router';
import {GenelayarComponent} from './Pages/genelayar/genelayar.component';
import {JetonekleComponent} from './Pages/jetonekle/jetonekle.component';
import {SoruEkleComponent} from './Pages/soru-ekle/soru-ekle.component';
import {SoruislemleriComponent} from './Pages/soruislemleri/soruislemleri.component';
import {TumsorularComponent} from './Pages/tumsorular/tumsorular.component';
import {NgCircleProgressModule} from 'ng-circle-progress';
import {KategoriekleComponent} from './Pages/kategoriekle/kategoriekle.component';
import {TumkategorilerComponent} from './Pages/tumkategoriler/tumkategoriler.component';
import {AngularFirestore, AngularFirestoreModule} from '@angular/fire/firestore';
import { LoginComponent } from './login/login.component';



@NgModule({
  declarations: [
    AppComponent,
    CreateUserComponent,
    UserListComponent,
    NavComponent,
    HomepageComponent,
    KullaniciIslemComponent,
    UygulamaislemComponent,
    GenelayarComponent,
    JetonekleComponent,
    SoruEkleComponent,
    SoruislemleriComponent,
    TumsorularComponent,
    KategoriekleComponent,
    TumkategorilerComponent,
    LoginComponent,


  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRoutes),
    AngularFireModule.initializeApp(environment.firebaseConfig),
    AngularFireDatabaseModule,
    FormsModule,
    AngularFirestoreModule,
    NgCircleProgressModule.forRoot({
      // set defaults here
      radius: 100,
      outerStrokeWidth: 16,
      innerStrokeWidth: 8,
      outerStrokeColor: '#78C000',
      innerStrokeColor: '#C7E596',
      animationDuration: 300,

    }),
    ReactiveFormsModule,


  ],
  providers: [AppRoutingModule],
  bootstrap: [AppComponent]
})
export class AppModule {
}
