import {Injectable} from '@angular/core';

import {SorularModel} from '../Models/SorularModel';

import {AngularFirestore, AngularFirestoreCollection} from '@angular/fire/firestore';
import firebase from 'firebase';
import FieldValue = firebase.firestore.FieldValue;
import {KategoriModel} from '../Models/KategoriModel';


@Injectable({
  providedIn: 'root'
})
export class UserServiceService {
  private dbPath = '/Sorular';
  private katPath = '/Sorular';


  tutorialsRef: AngularFirestoreCollection<SorularModel> = null;
  katref: AngularFirestoreCollection<KategoriModel> = null;


  constructor(private db: AngularFirestore) {
    this.tutorialsRef = db.collection(this.dbPath);
    this.katref = db.collection(this.katPath);
  }

  getAll(): AngularFirestoreCollection<SorularModel> {
    return this.tutorialsRef;
  }

  getAllKategori(): AngularFirestoreCollection<KategoriModel> {
    return this.katref;
  }

  createKategori(katname: string): any {
    return this.db.collection('Sorular').doc(katname);
  }

  create(tutorial: SorularModel, katname: string): any {
    return this.db.collection('Sorular').doc(katname).update({

      sorular: FieldValue.arrayUnion({...tutorial})
    });
  }

  update(id: string, data: any): Promise<void> {
    return this.tutorialsRef.doc(id).update(data);
  }

  delete(id: string): Promise<void> {
    return this.tutorialsRef.doc(id).delete();
  }
}
