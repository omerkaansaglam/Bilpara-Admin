import {Component, OnInit} from '@angular/core';
import {map} from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'BilPara';
  date;


  ngOnInit(): void {
    this.date = new Date();
  }
}
