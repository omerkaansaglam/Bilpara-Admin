import {SorularModel} from './SorularModel';

export class KategoriModel {

  id: number;
  katName: string;
  katDesc: string;
  isActive: boolean;
  sorular: SorularModel;
  sorularId: number;

}
