export class SorularModel {
  id: number;
  ad: string;
  puan: number;
  dogruCevap: string;
  cevap1: string;
  cevap2: string;
  cevap3: string;
  cevap4: string;

}
