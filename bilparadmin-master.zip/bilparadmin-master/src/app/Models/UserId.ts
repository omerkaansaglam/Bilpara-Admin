export class UserId {
  uID: string;

}
