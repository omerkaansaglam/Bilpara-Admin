export class UserModel {
  id: string;
  ad: string;
  soyad: string;
  email: string;
  tel: string;
  jeton: number;
  isActive: boolean;
  status: boolean;
  profilImage: string;
  createTime: string;
  onlineTime: string;
  lastSign: string;
  userName: string;
  puan: number;

}
