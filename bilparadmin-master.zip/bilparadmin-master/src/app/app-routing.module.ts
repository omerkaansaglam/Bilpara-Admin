import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {Routes} from '@angular/router';
import {HomepageComponent} from './Pages/homepage/homepage.component';
import {KullaniciIslemComponent} from './Pages/kullanici-islem/kullanici-islem.component';

import {CreateUserComponent} from './Pages/uaerUpdate/user-update.component';
import {UygulamaislemComponent} from './Pages/uygulamaislem/uygulamaislem.component';
import {GenelayarComponent} from './Pages/genelayar/genelayar.component';
import {UserListComponent} from './Pages/user-list/user-list.component';
import {JetonekleComponent} from './Pages/jetonekle/jetonekle.component';
import {SoruEkleComponent} from './Pages/soru-ekle/soru-ekle.component';
import {SoruislemleriComponent} from './Pages/soruislemleri/soruislemleri.component';
import {TumsorularComponent} from './Pages/tumsorular/tumsorular.component';
import {KategoriekleComponent} from './Pages/kategoriekle/kategoriekle.component';
import {TumkategorilerComponent} from './Pages/tumkategoriler/tumkategoriler.component';
import {LoginComponent} from './login/login.component';


export const appRoutes: Routes = [
  {path: 'login', component: LoginComponent},
  {path: 'homepage', component: HomepageComponent},
  {
    path: 'kullaniciislem', component: KullaniciIslemComponent, children: [
      {path: '', redirectTo: 'userlist', pathMatch: 'full'},
      {path: 'userlist', component: UserListComponent},
      {path: 'createUser', component: CreateUserComponent},
      {path: 'jetonekle', component: JetonekleComponent},

    ]
  },
  {
    path: 'uygulamaislem', component: UygulamaislemComponent
  },
  {path: 'genelAyar', component: GenelayarComponent},
  {
    path: 'soruislemleri', component: SoruislemleriComponent, children: [
      {path: '', redirectTo: 'tumsorular', pathMatch: 'full'},
      {path: 'tumsorular', component: TumsorularComponent},
      {path: 'soruekle', component: SoruEkleComponent},
      {path: 'kategoriekle', component: KategoriekleComponent},
      {path: 'tumkategoriler', component: TumkategorilerComponent},


    ]
  },


  {path: 'uygulamaislem', component: UygulamaislemComponent},


  {path: '', redirectTo: 'homepage', pathMatch: 'full'},


];

export class AppRoutingModule {
}
