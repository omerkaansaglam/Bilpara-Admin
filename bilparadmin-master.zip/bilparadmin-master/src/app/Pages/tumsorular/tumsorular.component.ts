import {Component, OnInit} from '@angular/core';
import {SorularModel} from '../../Models/SorularModel';
import {AngularFireDatabase} from '@angular/fire/database';
import {UserServiceService} from '../../Services/user-service.service';
import {map} from 'rxjs/operators';
import {KategoriModel} from '../../Models/KategoriModel';
import {AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument} from '@angular/fire/firestore';

@Component({
  selector: 'app-tumsorular',
  templateUrl: './tumsorular.component.html',
  styleUrls: ['./tumsorular.component.css']
})
export class TumsorularComponent implements OnInit {
  soruCollection: AngularFirestoreCollection<any>;
  soruDetayCollection: AngularFirestoreDocument<any>;
  collection: any;
  soruDetay: any;
  topSoru;
  katname = '';

  emrebey: any;


  aliveli: [
    {
      ad,
      cevap1,
      cevap2,
      cevap3,
      ceva4,
      dogruCevap,
      puan

    }
  ];


  constructor(private  store: AngularFirestore) {
  }


  ngOnInit(): void {

    this.soruCollection = this.store.collection<any>('Sorular');

    this.collection = this.soruCollection.snapshotChanges()
      .pipe(
        map(actions => actions.map(a => a.payload.doc.data()))
      );


    this.soruCollection.get().subscribe((value) => {

      this.topSoru = value.docs.length;

    });
  }

  selectChangeHandler(event: any): any {

    this.katname = event.target.value;

    this.store.collection('Sorular').doc(this.katname).get().forEach(value => {
      this.aliveli = value.get('sorular');


    });


    // this.store.collection('Sorular')
    //   .doc(this.katname)
    //   .ref
    //   .get().then((doc) => {
    //   if (doc.exists) {
    //     this.aliveli = doc.get('sorular')[0];
    //     console.log('Document data:', this.aliveli);
    //   } else {
    //     console.log('No such document!');
    //   }
    // }).catch((error) => {
    //   console.log('Error getting document:', error);
    // });

  }
}
