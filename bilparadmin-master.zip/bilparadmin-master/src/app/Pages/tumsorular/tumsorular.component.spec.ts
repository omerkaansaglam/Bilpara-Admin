import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TumsorularComponent } from './tumsorular.component';

describe('TumsorularComponent', () => {
  let component: TumsorularComponent;
  let fixture: ComponentFixture<TumsorularComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TumsorularComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TumsorularComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
