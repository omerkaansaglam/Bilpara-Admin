import {Component, OnInit} from '@angular/core';
import {UserServiceService} from '../../Services/user-service.service';
import {UserModel} from '../../Models/UserModel';
import {AngularFireAuth} from '@angular/fire/auth';
import {debuglog} from 'util';
import {AngularFireDatabase} from '@angular/fire/database';
import {UserId} from '../../Models/UserId';
import {Observable} from 'rxjs';
import * as admin from 'firebase-admin';
import {auth} from 'firebase-admin/lib/auth';
import UserIdentifier = auth.UserIdentifier;
import {FormGroup, FormControl} from '@angular/forms';

@Component({
  selector: 'app-create-user',
  templateUrl: './user-update.component.html',
  styleUrls: ['./user-update.component.css']
})
export class CreateUserComponent implements OnInit {
  user: UserModel = new UserModel();
  ident: UserIdentifier[];
  submitted = false;
  result;
  email;
  sifre;
  ad;
  soyad;
  telefon;
  message = false;

  // tslint:disable-next-line:max-line-length
  constructor(private userService: UserServiceService, private fireauth: AngularFireAuth, private fDb: AngularFireDatabase) {


  }

  ngOnInit(): void {
  }



  // userSil(): void {
  //   admin.initializeApp().auth().getUsers(this.ident).then(value => {
  //
  //
  //   });
  //
  // }

  newTutorial(): void {
    this.submitted = false;
    this.user = new UserModel();
  }

  // tslint:disable-next-line:typedef


  // tslint:disable-next-line:typedef
  async register(email: string, sifre: string, ad, soyad, telefon) {

    await this.fireauth.createUserWithEmailAndPassword(email, sifre).then(value => {

      console.log(value.user.uid);

      console.log(value.user.uid);
      this.createUserData(email, ad, soyad, telefon, value);

    });

  }

  // tslint:disable-next-line:typedef
  async createUserData(Email, Ad, Soyad, Telefon, value) {

    await this.fDb.database.ref().child('Users').child(value.user.uid).set({

      id: value.user.uid,
      ad: Ad,
      soyad: Soyad,
      email: Email,
      jeton: 0,
      tel: Telefon,
      isActive: true,
      status: null,
      profilImage: '',
      createTime: 'string',
      onlineTime: 'string',
      lastSign: 'string',
      userName: '',
      puan: 0,


    }).finally(() => {
      this.message = true;

    });

  }

  // tslint:disable-next-line:typedef


}
