import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-soruislemleri',
  templateUrl: './soruislemleri.component.html',
  styleUrls: ['./soruislemleri.component.css']
})
export class SoruislemleriComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
