import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SoruislemleriComponent } from './soruislemleri.component';

describe('SoruislemleriComponent', () => {
  let component: SoruislemleriComponent;
  let fixture: ComponentFixture<SoruislemleriComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SoruislemleriComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SoruislemleriComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
