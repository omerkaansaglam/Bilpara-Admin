import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GenelayarComponent } from './genelayar.component';

describe('GenelayarComponent', () => {
  let component: GenelayarComponent;
  let fixture: ComponentFixture<GenelayarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GenelayarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GenelayarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
