import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-genelayar',
  templateUrl: './genelayar.component.html',
  styleUrls: ['./genelayar.component.css']
})
export class GenelayarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
