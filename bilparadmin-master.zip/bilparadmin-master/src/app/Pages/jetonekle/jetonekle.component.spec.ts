import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JetonekleComponent } from './jetonekle.component';

describe('JetonekleComponent', () => {
  let component: JetonekleComponent;
  let fixture: ComponentFixture<JetonekleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ JetonekleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(JetonekleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
