import {Component, OnInit} from '@angular/core';
import {AngularFireDatabase, snapshotChanges} from '@angular/fire/database';
import {AngularFirestore} from '@angular/fire/firestore';
import firebase from 'firebase';
import DocumentSnapshot = firebase.firestore.DocumentSnapshot;

@Component({
  selector: 'app-jetonekle',
  templateUrl: './jetonekle.component.html',
  styleUrls: ['./jetonekle.component.css']
})
export class JetonekleComponent implements OnInit {
  submitted = false;
  uid;
  jetonMiktar;
  oncekiJeton;

  constructor(private db: AngularFirestore) {
  }

  ngOnInit(): void {
  }

  jetonEkle(uid, miktar): void {
    this.db.collection('users').doc(uid).get().subscribe((value => {

      this.jetonMiktar = value.get('jeton');

      this.jetOnyeni(uid, miktar, this.jetonMiktar);
    }));
  }

  jetOnyeni(uid, miktar, jetonmiktar): void {

    this.db.collection('users').doc(uid).update({
      jeton: jetonmiktar + miktar
    }).then(value => this.submitted = true);
  }

  jetonSil(uid, miktar): void {
    this.db.collection('users').doc(uid).get().subscribe((value => {

      this.jetonMiktar = value.get('jeton');

      this.jetonSilUpdate(uid, miktar, this.jetonMiktar);
    }));
  }


  jetonSilUpdate(uid, miktar, jetonmiktar): void {

    this.db.collection('users').doc(uid).update({
      jeton: jetonmiktar - miktar
    }).then(value => this.submitted = true);
  }


  valueClean(): void {

    this.submitted = false;
    this.uid = null;
    this.jetonMiktar = null;
  }
}
