import {Component, OnInit} from '@angular/core';
import {map} from 'rxjs/operators';
import {AngularFirestore, AngularFirestoreCollection} from '@angular/fire/firestore';


@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {
  userCollection: AngularFirestoreCollection<any>;
  collection: any;
  topUsers = 0;
  onlineUsers = 0;

  macyapanUser = 0;

  constructor(private  store: AngularFirestore) {
  }

  ngOnInit(): void {
    this.getUserData();

  }

  async getUserData(): Promise<any> {

    this.userCollection = await this.store.collection<any>('users'),

      this.collection = await this.userCollection.snapshotChanges()
        .pipe(
          map(actions => actions.map(a => a.payload.doc.data()))
        );
    await this.userCollection.get().subscribe(value => {

      this.topUsers = value.docs.length;


    });


    await this.store.collection('users', ref => ref
      .where('status', '==', true)  // giving error
    )
      .snapshotChanges()
      .subscribe(response => {
        this.onlineUsers = response.length;

      });

    await this.store.collection('users', ref => ref
      .where('odadaMi', '==', true)  // giving error
    )
      .snapshotChanges()
      .subscribe(response => {
        this.macyapanUser = response.length;

      });

  }
}
