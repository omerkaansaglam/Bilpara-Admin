import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kullanici-islem',
  templateUrl: './kullanici-islem.component.html',
  styleUrls: ['./kullanici-islem.component.css']
})
export class KullaniciIslemComponent implements OnInit {
  currentTab: string;

  constructor() { }

  ngOnInit(): void {
  }

}
