import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KullaniciIslemComponent } from './kullanici-islem.component';

describe('KullaniciIslemComponent', () => {
  let component: KullaniciIslemComponent;
  let fixture: ComponentFixture<KullaniciIslemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KullaniciIslemComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KullaniciIslemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
