import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SoruEkleComponent } from './soru-ekle.component';

describe('SoruEkleComponent', () => {
  let component: SoruEkleComponent;
  let fixture: ComponentFixture<SoruEkleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SoruEkleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SoruEkleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
