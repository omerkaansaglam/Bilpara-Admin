import {Component, OnInit} from '@angular/core';
import {AngularFireAuth} from '@angular/fire/auth';
import {AngularFireDatabase} from '@angular/fire/database';
import {SorularModel} from '../../Models/SorularModel';
import {UserServiceService} from '../../Services/user-service.service';
import {map} from 'rxjs/operators';
import {AngularFirestore} from '@angular/fire/firestore';
import {debuglog} from 'util';
import {parse} from 'ts-node';
import firebase from 'firebase';
import FieldValue = firebase.firestore.FieldValue;
import {KategoriModel} from '../../Models/KategoriModel';

@Component({
  selector: 'app-soru-ekle',
  templateUrl: './soru-ekle.component.html',
  styleUrls: ['./soru-ekle.component.css']
})
export class SoruEkleComponent implements OnInit {
  submitted = false;

  katmodel: KategoriModel[];
  sorumodel: SorularModel = new SorularModel();
  soruDat: SorularModel[];
  currentIndex = -1;
  currentTutorial = null;
  katname = '';


  constructor(private db: AngularFireDatabase, private userService: UserServiceService, private store: AngularFirestore) {
  }

  ngOnInit(): void {
    this.retrieveTutorials();
  }


  saveTutorial(katname: string): void {
    this.userService.create(this.sorumodel, katname).then(() => {
      console.log('Başarıyla oluşturldu.');
      this.submitted = true;
    });


  }

  // tslint:disable-next-line:typedef
  selectChangeHandler(event: any) {

    this.katname = event.target.value;
  }

  refreshList(): void {
    this.currentTutorial = null;
    this.currentIndex = -1;
    this.retrieveTutorials();
  }

  retrieveTutorials(): void {
    this.userService.getAllKategori().snapshotChanges().pipe(
      map(changes =>
        changes.map(c =>
          ({id: c.payload.doc.id, ...c.payload.doc.data()})
        )
      )
    ).subscribe(data => {
      this.katmodel = data;
    });
  }

  setActiveTutorial(tutorial, index): void {
    this.currentTutorial = tutorial;
    this.currentIndex = index;
  }


}
