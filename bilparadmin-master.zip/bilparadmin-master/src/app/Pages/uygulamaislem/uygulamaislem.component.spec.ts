import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UygulamaislemComponent } from './uygulamaislem.component';

describe('UygulamaislemComponent', () => {
  let component: UygulamaislemComponent;
  let fixture: ComponentFixture<UygulamaislemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UygulamaislemComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UygulamaislemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
