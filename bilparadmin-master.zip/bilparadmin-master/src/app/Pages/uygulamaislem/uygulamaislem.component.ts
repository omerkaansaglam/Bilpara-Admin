import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uygulamaislem',
  templateUrl: './uygulamaislem.component.html',
  styleUrls: ['./uygulamaislem.component.css']
})
export class UygulamaislemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
