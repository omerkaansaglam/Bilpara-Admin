import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KategoriekleComponent } from './kategoriekle.component';

describe('KategoriekleComponent', () => {
  let component: KategoriekleComponent;
  let fixture: ComponentFixture<KategoriekleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KategoriekleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KategoriekleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
