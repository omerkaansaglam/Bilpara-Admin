import {Component, OnInit} from '@angular/core';
import {AngularFireDatabase} from '@angular/fire/database';
import {UserServiceService} from '../../Services/user-service.service';
import {KategoriModel} from '../../Models/KategoriModel';
import {AngularFirestore} from '@angular/fire/firestore';

@Component({
  selector: 'app-kategoriekle',
  templateUrl: './kategoriekle.component.html',
  styleUrls: ['./kategoriekle.component.css']
})
export class KategoriekleComponent implements OnInit {
  submitted = false;
  kategoriModel: KategoriModel = new KategoriModel();
  katMod: KategoriModel[];
  katNames: string;
  kategoriAdi: string;

  constructor(private db: AngularFireDatabase, private userService: UserServiceService, private store: AngularFirestore) {
  }

  ngOnInit(): void {
  }

  // tslint:disable-next-line:typedef
  async kategoriOlustur(katName: string) {
    await this.store.collection('Sorular').doc(katName).set({

      katName: katName
    }).then(value => {
      this.store.collection('Sorular').doc(katName).collection('waitingUsers').doc('waitingList').set({
        asd: ''
      });

    });
  }
}
