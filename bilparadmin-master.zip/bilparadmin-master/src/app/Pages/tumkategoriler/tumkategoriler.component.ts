import {Component, OnInit} from '@angular/core';
import {map} from 'rxjs/operators';
import {UserServiceService} from '../../Services/user-service.service';
import {AngularFireDatabase} from '@angular/fire/database';
import {AngularFireAuth} from '@angular/fire/auth';
import {KategoriModel} from '../../Models/KategoriModel';
import {AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument} from '@angular/fire/firestore';

@Component({
  selector: 'app-tumkategoriler',
  templateUrl: './tumkategoriler.component.html',
  styleUrls: ['./tumkategoriler.component.css']
})
export class TumkategorilerComponent implements OnInit {


  soruCollection: AngularFirestoreCollection<any>;

  collection: any;
  topSoru;

  constructor(private  store: AngularFirestore) {
  }

  ngOnInit(): void {
    this.soruCollection = this.store.collection<any>('Sorular');

    this.collection = this.soruCollection.snapshotChanges()
      .pipe(
        map(actions => actions.map(a => a.payload.doc.data()))
      );


    this.soruCollection.get().subscribe((value) => {

      this.topSoru = value.docs.length;

    });

  }



}
