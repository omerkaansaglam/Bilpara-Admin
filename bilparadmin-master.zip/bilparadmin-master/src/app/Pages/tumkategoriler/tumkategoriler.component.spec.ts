import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TumkategorilerComponent } from './tumkategoriler.component';

describe('TumkategorilerComponent', () => {
  let component: TumkategorilerComponent;
  let fixture: ComponentFixture<TumkategorilerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TumkategorilerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TumkategorilerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
