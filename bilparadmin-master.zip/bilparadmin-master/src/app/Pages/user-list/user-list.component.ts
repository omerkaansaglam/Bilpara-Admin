import {Component, OnInit} from '@angular/core';
import {UserServiceService} from '../../Services/user-service.service';
import {map} from 'rxjs/operators';


import {AngularFireAuth} from '@angular/fire/auth';
import {AngularFirestore, AngularFirestoreCollection} from '@angular/fire/firestore';


@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {

  userCollection: AngularFirestoreCollection<any>;
  collection: any;
  topUsers;
  onlineUsers;
  message = false;


  constructor(private  store: AngularFirestore) {
  }

  ngOnInit(): void {
    this.userCollection = this.store.collection<any>('users'),

      this.collection = this.userCollection.snapshotChanges()
        .pipe(
          map(actions => actions.map(a => a.payload.doc.data()))
        );
    this.userCollection.get().subscribe(value => {

      this.topUsers = value.docs.length;

    });


    this.store.collection('users', ref => ref
      .where('status', '==', true)  // giving error
    )
      .snapshotChanges()
      .subscribe(response => {
        this.onlineUsers = response.length;

      });
  }


}
